﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;

namespace car
{
    public partial class Users : Form
    {
        public Users()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|Datadirectory|carrental.mdf;Integrated Security=True");
        private void populate()
        {
            con.Open();
            string query = "select * from Usertbl";

           SqlDataAdapter da = new SqlDataAdapter(query,con);
           SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            usersDGV.DataSource = ds.Tables[0];
            con.Close();
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            if (uid.Text == "" || uname.Text == "" || upass.Text == "")
            {
                MessageBox.Show("missing information");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "insert into Usertbl values(" + uid.Text + ",'" + uname.Text + "','" + upass.Text + "')";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("User Add");
                    con.Close();
                    populate();
                    uid.Text = uname.Text = upass.Text =string.Empty;
                    uid.Focus();

                }
                catch (Exception myex)
                {
                    MessageBox.Show(myex.Message);
                }
            }
               
            




        }
       
        private void User_Load(object sender, EventArgs e)
        {
            string sql = "select * from Usertbl";
            SqlDataAdapter da = new SqlDataAdapter(sql,con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            usersDGV.DataSource = dt;




            
            populate();

        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            if (uid.Text == "" )
            {
                MessageBox.Show("missing information");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "delete from Usertbl where id="+uid.Text+";";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("User Delete");
                    con.Close();
                    populate();
                    uid.Text = uname.Text = upass.Text = string.Empty;
                    uid.Focus();

                }
                catch (Exception myex)
                {
                    MessageBox.Show(myex.Message);
                }
            }


        }




        private void btnback_Click(object sender, EventArgs e)
        {
           
         
            this.Hide();
            Mainform m1 = new Mainform();
            m1.Show();
        }

        private void btnedit_Click(object sender, EventArgs e)
        {

            if (uid.Text == "" || uname.Text == "" || upass.Text == "")
            {
                MessageBox.Show("missing information");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "update Usertbl set uname='"+uname.Text+"',upass='"+upass.Text+"' where id="+uid.Text+";";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("User Update");
                    con.Close();
                    populate();
                    uid.Text = uname.Text = upass.Text = string.Empty;
                    uid.Focus();
                }
                catch (Exception myex)
                {
                    MessageBox.Show(myex.Message);
                }
            }


        }

       

        private void label4_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void uid_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Only Number");
            }
        }

       

       

        private void usersDGV_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            uid.Text = usersDGV.Rows[e.RowIndex].Cells[0].Value.ToString();
            uname.Text = usersDGV.Rows[e.RowIndex].Cells[1].Value.ToString();
            upass.Text = usersDGV.Rows[e.RowIndex].Cells[2].Value.ToString();
        }
    }
}
