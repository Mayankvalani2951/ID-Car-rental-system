﻿namespace car
{
    partial class Users
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Users));
            this.btnadd = new System.Windows.Forms.Button();
            this.upass = new System.Windows.Forms.TextBox();
            this.uid = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.uname = new System.Windows.Forms.TextBox();
            this.btnedit = new System.Windows.Forms.Button();
            this.btndelete = new System.Windows.Forms.Button();
            this.btnback = new System.Windows.Forms.Button();
            this.usertblBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
//            this.carrentalDataSet9 = new car.carrentalDataSet9();
            this.usertblBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
         //   this.carrentalDataSet8 = new car.carrentalDataSet8();
            this.usertblBindingSource = new System.Windows.Forms.BindingSource(this.components);
         //   this.carrentalDataSet1 = new car.carrentalDataSet1();
          //  this.carrentalDataSet = new car.carrentalDataSet();
            this.carrentalDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
         //   this.usertblTableAdapter = new car.carrentalDataSet1TableAdapters.UsertblTableAdapter();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            //this.carrentalDataSet7 = new car.carrentalDataSet7();
            this.usertblBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            //this.usertblTableAdapter1 = new car.carrentalDataSet7TableAdapters.UsertblTableAdapter();
           // this.usertblTableAdapter2 = new car.carrentalDataSet8TableAdapters.UsertblTableAdapter();
           // this.usertblTableAdapter3 = new car.carrentalDataSet9TableAdapters.UsertblTableAdapter();
            this.usertblBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            //this.carrentalDataSet17 = new car.carrentalDataSet17();
            //this.usertblTableAdapter4 = new car.carrentalDataSet17TableAdapters.UsertblTableAdapter();
            this.usertblBindingSource5 = new System.Windows.Forms.BindingSource(this.components);
           // this.carrentalDataSet21 = new car.carrentalDataSet21();
           // this.usertblTableAdapter5 = new car.carrentalDataSet21TableAdapters.UsertblTableAdapter();
            this.usersDGV = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.usertblBindingSource3)).BeginInit();
          // (System.ComponentModel.ISupportInitialize)(this.carrentalDataSet9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.usertblBindingSource2)).BeginInit();
          // (System.ComponentModel.ISupportInitialize)(this.carrentalDataSet8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.usertblBindingSource)).BeginInit();
           // ((System.ComponentModel.ISupportInitialize)(this.carrentalDataSet1)).BeginInit();
           // ((System.ComponentModel.ISupportInitialize)(this.carrentalDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.carrentalDataSetBindingSource)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
           // ((System.ComponentModel.ISupportInitialize)(this.carrentalDataSet7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.usertblBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.usertblBindingSource4)).BeginInit();
           // ((System.ComponentModel.ISupportInitialize)(this.carrentalDataSet17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.usertblBindingSource5)).BeginInit();
            //((System.ComponentModel.ISupportInitialize)(this.carrentalDataSet21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.usersDGV)).BeginInit();
            this.SuspendLayout();
            // 
            // btnadd
            // 
            this.btnadd.BackColor = System.Drawing.Color.Yellow;
            this.btnadd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnadd.Location = new System.Drawing.Point(34, 271);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(82, 35);
            this.btnadd.TabIndex = 10;
            this.btnadd.Text = "Add";
            this.btnadd.UseVisualStyleBackColor = false;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click);
            // 
            // upass
            // 
            this.upass.Location = new System.Drawing.Point(124, 208);
            this.upass.Margin = new System.Windows.Forms.Padding(4);
            this.upass.Name = "upass";
            this.upass.Size = new System.Drawing.Size(207, 26);
            this.upass.TabIndex = 9;
            // 
            // uid
            // 
            this.uid.Location = new System.Drawing.Point(124, 124);
            this.uid.Margin = new System.Windows.Forms.Padding(4);
            this.uid.Name = "uid";
            this.uid.Size = new System.Drawing.Size(207, 26);
            this.uid.TabIndex = 8;
            this.uid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.uid_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(30, 208);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 20);
            this.label2.TabIndex = 7;
            this.label2.Text = "Password";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(30, 124);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(25, 20);
            this.label1.TabIndex = 6;
            this.label1.Text = "Id";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(30, 166);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 20);
            this.label3.TabIndex = 11;
            this.label3.Text = "Name";
            // 
            // uname
            // 
            this.uname.Location = new System.Drawing.Point(124, 166);
            this.uname.Margin = new System.Windows.Forms.Padding(4);
            this.uname.Name = "uname";
            this.uname.Size = new System.Drawing.Size(207, 26);
            this.uname.TabIndex = 12;
            // 
            // btnedit
            // 
            this.btnedit.BackColor = System.Drawing.Color.Yellow;
            this.btnedit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnedit.Location = new System.Drawing.Point(137, 271);
            this.btnedit.Name = "btnedit";
            this.btnedit.Size = new System.Drawing.Size(82, 35);
            this.btnedit.TabIndex = 13;
            this.btnedit.Text = "Edit";
            this.btnedit.UseVisualStyleBackColor = false;
            this.btnedit.Click += new System.EventHandler(this.btnedit_Click);
            // 
            // btndelete
            // 
            this.btndelete.BackColor = System.Drawing.Color.Yellow;
            this.btndelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btndelete.Location = new System.Drawing.Point(249, 271);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(82, 35);
            this.btndelete.TabIndex = 14;
            this.btndelete.Text = "Delete";
            this.btndelete.UseVisualStyleBackColor = false;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // btnback
            // 
            this.btnback.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnback.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnback.Location = new System.Drawing.Point(137, 322);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(82, 35);
            this.btnback.TabIndex = 15;
            this.btnback.Text = "Back";
            this.btnback.UseVisualStyleBackColor = false;
            this.btnback.Click += new System.EventHandler(this.btnback_Click);
            // 
            // usertblBindingSource3
            // 
            this.usertblBindingSource3.DataMember = "Usertbl";
           
            this.usertblBindingSource2.DataMember = "Usertbl";
           
            this.usertblBindingSource.DataMember = "Usertbl";
           this.carrentalDataSetBindingSource.Position = 0;
           
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Location = new System.Drawing.Point(-2, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(783, 90);
            this.panel1.TabIndex = 17;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Algerian", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(227, 19);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(387, 54);
            this.label5.TabIndex = 40;
            this.label5.Text = "User Register";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(0, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(140, 114);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 39;
            this.pictureBox2.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(744, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(21, 20);
            this.label4.TabIndex = 18;
            this.label4.Text = "X";
            this.label4.Click += new System.EventHandler(this.label4_Click_1);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Red;
            this.panel2.Location = new System.Drawing.Point(-2, 425);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(783, 22);
            this.panel2.TabIndex = 35;
            
            this.usertblBindingSource1.DataMember = "Usertbl";
            
            this.usertblBindingSource4.DataMember = "Usertbl";
            
           
           
            this.usertblBindingSource5.DataMember = "Usertbl";
           
            
            this.usersDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.usersDGV.Location = new System.Drawing.Point(395, 124);
            this.usersDGV.Name = "usersDGV";
            this.usersDGV.Size = new System.Drawing.Size(338, 190);
            this.usersDGV.TabIndex = 36;
            this.usersDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.usersDGV_CellContentClick_1);
            // 
            // Users
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Turquoise;
            this.ClientSize = new System.Drawing.Size(775, 444);
            this.Controls.Add(this.usersDGV);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnback);
            this.Controls.Add(this.btndelete);
            this.Controls.Add(this.btnedit);
            this.Controls.Add(this.uname);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnadd);
            this.Controls.Add(this.upass);
            this.Controls.Add(this.uid);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "Users";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "User";
            this.Load += new System.EventHandler(this.User_Load);
            ((System.ComponentModel.ISupportInitialize)(this.usertblBindingSource3)).EndInit();
           // ((System.ComponentModel.ISupportInitialize)(this.carrentalDataSet9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.usertblBindingSource2)).EndInit();
           // ((System.ComponentModel.ISupportInitialize)(this.carrentalDataSet8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.usertblBindingSource)).EndInit();
           // ((System.ComponentModel.ISupportInitialize)(this.carrentalDataSet1)).EndInit();
           // ((System.ComponentModel.ISupportInitialize)(this.carrentalDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.carrentalDataSetBindingSource)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
           // ((System.ComponentModel.ISupportInitialize)(this.carrentalDataSet7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.usertblBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.usertblBindingSource4)).EndInit();
           // ((System.ComponentModel.ISupportInitialize)(this.carrentalDataSet17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.usertblBindingSource5)).EndInit();
           // ((System.ComponentModel.ISupportInitialize)(this.carrentalDataSet21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.usersDGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.TextBox upass;
        private System.Windows.Forms.TextBox uid;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox uname;
        private System.Windows.Forms.Button btnedit;
        private System.Windows.Forms.Button btndelete;
        private System.Windows.Forms.Button btnback;
        private System.Windows.Forms.BindingSource carrentalDataSetBindingSource;
       // private carrentalDataSet carrentalDataSet;
       // private carrentalDataSet1 carrentalDataSet1;
        private System.Windows.Forms.BindingSource usertblBindingSource;
      //  private carrentalDataSet1TableAdapters.UsertblTableAdapter usertblTableAdapter;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label5;
       // private carrentalDataSet7 carrentalDataSet7;
        private System.Windows.Forms.BindingSource usertblBindingSource1;
       // private carrentalDataSet7TableAdapters.UsertblTableAdapter usertblTableAdapter1;
       // private carrentalDataSet8 carrentalDataSet8;
        private System.Windows.Forms.BindingSource usertblBindingSource2;
       // private carrentalDataSet8TableAdapters.UsertblTableAdapter usertblTableAdapter2;
       // private carrentalDataSet9 carrentalDataSet9;
        private System.Windows.Forms.BindingSource usertblBindingSource3;
       // private carrentalDataSet9TableAdapters.UsertblTableAdapter usertblTableAdapter3;
       // private carrentalDataSet17 carrentalDataSet17;
        private System.Windows.Forms.BindingSource usertblBindingSource4;
      //  private carrentalDataSet17TableAdapters.UsertblTableAdapter usertblTableAdapter4;
       // private carrentalDataSet21 carrentalDataSet21;
        private System.Windows.Forms.BindingSource usertblBindingSource5;
       // private carrentalDataSet21TableAdapters.UsertblTableAdapter usertblTableAdapter5;
        private System.Windows.Forms.DataGridView usersDGV;
    }
}