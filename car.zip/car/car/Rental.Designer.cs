﻿namespace car
{
    partial class Rental
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Rental));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnback = new System.Windows.Forms.Button();
            this.btndelete = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.btnadd = new System.Windows.Forms.Button();
            this.idtb = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.rentaltblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label7 = new System.Windows.Forms.Label();
            this.rentfee = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
          this.rentaltblBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
         this.rentaltblBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
          this.rentdate = new System.Windows.Forms.DateTimePicker();
            this.returndate = new System.Windows.Forms.DateTimePicker();
            this.carreg = new System.Windows.Forms.ComboBox();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.custname = new System.Windows.Forms.TextBox();
            this.rentaltblBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
          
            this.custidcb = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.rentaltblBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
           this.rentDGV = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentaltblBindingSource)).BeginInit();
           // ((System.ComponentModel.ISupportInitialize)(this.carrentalDataSet6)).BeginInit();
           // ((System.ComponentModel.ISupportInitialize)(this.carrentalDataSet10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentaltblBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentaltblBindingSource2)).BeginInit();
           // ((System.ComponentModel.ISupportInitialize)(this.carrentalDataSet11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentaltblBindingSource3)).BeginInit();
           // ((System.ComponentModel.ISupportInitialize)(this.carrentalDataSet20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentaltblBindingSource4)).BeginInit();
           // ((System.ComponentModel.ISupportInitialize)(this.carrentalDataSet25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentDGV)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(776, 71);
            this.panel1.TabIndex = 20;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(3, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(140, 85);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 38;
            this.pictureBox2.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Algerian", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(278, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(254, 54);
            this.label2.TabIndex = 37;
            this.label2.Text = "Rent Car";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Red;
            this.panel2.Location = new System.Drawing.Point(0, 422);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(783, 22);
            this.panel2.TabIndex = 40;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(8, 238);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(101, 20);
            this.label6.TabIndex = 52;
            this.label6.Text = "RentalDate";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(8, 202);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 20);
            this.label5.TabIndex = 51;
            this.label5.Text = "CustName";
            // 
            // btnback
            // 
            this.btnback.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnback.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnback.Location = new System.Drawing.Point(116, 381);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(108, 35);
            this.btnback.TabIndex = 50;
            this.btnback.Text = "Back";
            this.btnback.UseVisualStyleBackColor = false;
            this.btnback.Click += new System.EventHandler(this.btnback_Click);
            // 
            // btndelete
            // 
            this.btndelete.BackColor = System.Drawing.Color.Yellow;
            this.btndelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btndelete.Location = new System.Drawing.Point(197, 330);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(126, 35);
            this.btndelete.TabIndex = 49;
            this.btndelete.Text = "Delete";
            this.btndelete.UseVisualStyleBackColor = false;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(5, 126);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 20);
            this.label3.TabIndex = 46;
            this.label3.Text = "CarReg";
            // 
            // btnadd
            // 
            this.btnadd.BackColor = System.Drawing.Color.Yellow;
            this.btnadd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnadd.Location = new System.Drawing.Point(17, 330);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(126, 35);
            this.btnadd.TabIndex = 45;
            this.btnadd.Text = "Add";
            this.btnadd.UseVisualStyleBackColor = false;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click);
            // 
            // idtb
            // 
            this.idtb.Location = new System.Drawing.Point(116, 95);
            this.idtb.Margin = new System.Windows.Forms.Padding(4);
            this.idtb.Name = "idtb";
            this.idtb.Size = new System.Drawing.Size(207, 26);
            this.idtb.TabIndex = 43;
            this.idtb.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.rentid_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 95);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(25, 20);
            this.label4.TabIndex = 41;
            this.label4.Text = "Id";
            // 
            // rentaltblBindingSource
            // 
            this.rentaltblBindingSource.DataMember = "Rentaltbl";
          //  this.rentaltblBindingSource.DataSource = this.carrentalDataSet6;
            // 
            // carrentalDataSet6
            // 
           // this.carrentalDataSet6.DataSetName = "carrentalDataSet6";
           // this.carrentalDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // rentaltblTableAdapter
            // 
           // this.rentaltblTableAdapter.ClearBeforeFill = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(8, 270);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(103, 20);
            this.label7.TabIndex = 57;
            this.label7.Text = "ReturnDate";
            // 
            // rentfee
            // 
            this.rentfee.Location = new System.Drawing.Point(116, 297);
            this.rentfee.Margin = new System.Windows.Forms.Padding(4);
            this.rentfee.Name = "rentfee";
            this.rentfee.Size = new System.Drawing.Size(207, 26);
            this.rentfee.TabIndex = 59;
            this.rentfee.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.rentfee_KeyPress);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(8, 303);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(40, 20);
            this.label8.TabIndex = 60;
            this.label8.Text = "Fee";
            // 
            // carrentalDataSet10
            // 
           // this.carrentalDataSet10.DataSetName = "carrentalDataSet10";
           // this.carrentalDataSet10.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // rentaltblBindingSource1
            // 
            this.rentaltblBindingSource1.DataMember = "Rentaltbl";
           // this.rentaltblBindingSource1.DataSource = this.carrentalDataSet10;
            // 
            // rentaltblTableAdapter1
            // 
           // this.rentaltblTableAdapter1.ClearBeforeFill = true;
            // 
            // rentaltblBindingSource2
            // 
            this.rentaltblBindingSource2.DataMember = "Rentaltbl";
          //  this.rentaltblBindingSource2.DataSource = this.carrentalDataSet11;
            // 
            // carrentalDataSet11
            // 
           // this.carrentalDataSet11.DataSetName = "carrentalDataSet11";
          //  this.carrentalDataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // rentaltblTableAdapter2
            // 
          //  this.rentaltblTableAdapter2.ClearBeforeFill = true;
            // 
            // rentdate
            // 
            this.rentdate.Location = new System.Drawing.Point(116, 232);
            this.rentdate.Name = "rentdate";
            this.rentdate.Size = new System.Drawing.Size(207, 26);
            this.rentdate.TabIndex = 62;
            this.rentdate.ValueChanged += new System.EventHandler(this.rentdate_ValueChanged);
            // 
            // returndate
            // 
            this.returndate.Location = new System.Drawing.Point(116, 264);
            this.returndate.Name = "returndate";
            this.returndate.Size = new System.Drawing.Size(207, 26);
            this.returndate.TabIndex = 63;
            // 
            // carreg
            // 
            this.carreg.FormattingEnabled = true;
            this.carreg.Location = new System.Drawing.Point(116, 128);
            this.carreg.Name = "carreg";
            this.carreg.Size = new System.Drawing.Size(207, 28);
            this.carreg.TabIndex = 64;
            // 
            // custname
            // 
            this.custname.Enabled = false;
            this.custname.Location = new System.Drawing.Point(116, 199);
            this.custname.Margin = new System.Windows.Forms.Padding(4);
            this.custname.Name = "custname";
            this.custname.Size = new System.Drawing.Size(207, 26);
            this.custname.TabIndex = 66;
            // 
            // rentaltblBindingSource3
            // 
            this.rentaltblBindingSource3.DataMember = "Rentaltbl";
           // this.rentaltblBindingSource3.DataSource = this.carrentalDataSet20;
            // 
            // carrentalDataSet20
            // 
           // this.carrentalDataSet20.DataSetName = "carrentalDataSet20";
           // this.carrentalDataSet20.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // rentaltblTableAdapter3
            // 
          //  this.rentaltblTableAdapter3.ClearBeforeFill = true;
            // 
            // custidcb
            // 
            this.custidcb.FormattingEnabled = true;
            this.custidcb.Location = new System.Drawing.Point(116, 164);
            this.custidcb.Name = "custidcb";
            this.custidcb.Size = new System.Drawing.Size(207, 28);
            this.custidcb.TabIndex = 68;
            this.custidcb.SelectionChangeCommitted += new System.EventHandler(this.custidcb_SelectionChangeCommitted);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 164);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 20);
            this.label1.TabIndex = 69;
            this.label1.Text = "CustId";
            // 
            // rentaltblBindingSource4
            // 
            this.rentaltblBindingSource4.DataMember = "Rentaltbl";
           // this.rentaltblBindingSource4.DataSource = this.carrentalDataSet25;
            // 
            // carrentalDataSet25
            // 
           // this.carrentalDataSet25.DataSetName = "carrentalDataSet25";
          //  this.carrentalDataSet25.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // rentaltblTableAdapter4
            // 
           // this.rentaltblTableAdapter4.ClearBeforeFill = true;
            // 
            // rentDGV
            // 
            this.rentDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.rentDGV.Location = new System.Drawing.Point(397, 95);
            this.rentDGV.Name = "rentDGV";
            this.rentDGV.Size = new System.Drawing.Size(345, 270);
            this.rentDGV.TabIndex = 70;
            this.rentDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.rentDGV_CellContentClick);
            // 
            // Rental
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Turquoise;
            this.ClientSize = new System.Drawing.Size(775, 444);
            this.Controls.Add(this.rentDGV);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.custidcb);
            this.Controls.Add(this.custname);
            this.Controls.Add(this.carreg);
            this.Controls.Add(this.returndate);
            this.Controls.Add(this.rentdate);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.rentfee);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnback);
            this.Controls.Add(this.btndelete);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnadd);
            this.Controls.Add(this.idtb);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "Rental";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "v";
            this.Load += new System.EventHandler(this.Rental_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentaltblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentaltblBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentaltblBindingSource2)).EndInit();
        
            ((System.ComponentModel.ISupportInitialize)(this.rentaltblBindingSource3)).EndInit();
          
            ((System.ComponentModel.ISupportInitialize)(this.rentaltblBindingSource4)).EndInit();
          
            ((System.ComponentModel.ISupportInitialize)(this.rentDGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnback;
        private System.Windows.Forms.Button btndelete;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.TextBox idtb;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.BindingSource rentaltblBindingSource;
       private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox rentfee;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.BindingSource rentaltblBindingSource1;
       private System.Windows.Forms.BindingSource rentaltblBindingSource2;
       private System.Windows.Forms.DateTimePicker rentdate;
        private System.Windows.Forms.DateTimePicker returndate;
        private System.Windows.Forms.ComboBox carreg;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.TextBox custname;
        private System.Windows.Forms.BindingSource rentaltblBindingSource3;
        private System.Windows.Forms.ComboBox custidcb;
        private System.Windows.Forms.Label label1;
       private System.Windows.Forms.BindingSource rentaltblBindingSource4;
       private System.Windows.Forms.DataGridView rentDGV;
    }
}