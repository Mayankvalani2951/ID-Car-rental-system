﻿namespace car
{
    partial class Return
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Return));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnback = new System.Windows.Forms.Button();
            this.btnadd = new System.Windows.Forms.Button();
            this.customertblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label4 = new System.Windows.Forms.Label();
            this.IdTb = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.rdelay = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.rfine = new System.Windows.Forms.TextBox();
            this.rdate = new System.Windows.Forms.DateTimePicker();
            this.returntblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rentaltblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.rentaltblBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.returntblBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.returntblBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.returncarid = new System.Windows.Forms.TextBox();
            this.returnname = new System.Windows.Forms.TextBox();
            this.btndelete = new System.Windows.Forms.Button();
            this.rentaltblBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.returntblBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.rentaltblBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.returntblBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.rentaltblBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.returntblBindingSource5 = new System.Windows.Forms.BindingSource(this.components);
            this.returntblBindingSource6 = new System.Windows.Forms.BindingSource(this.components);
            this.rentDGV = new System.Windows.Forms.DataGridView();
            this.returnDGV = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.customertblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.returntblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentaltblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentaltblBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.returntblBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.returntblBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentaltblBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.returntblBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentaltblBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.returntblBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentaltblBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.returntblBindingSource5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.returntblBindingSource6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentDGV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.returnDGV)).BeginInit();
            this.SuspendLayout();
            // 
            // btnback
            // 
            this.btnback.BackColor = System.Drawing.Color.Black;
            this.btnback.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnback.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnback.ForeColor = System.Drawing.Color.Cyan;
            this.btnback.Location = new System.Drawing.Point(105, 365);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(130, 35);
            this.btnback.TabIndex = 71;
            this.btnback.Text = "Back";
            this.btnback.UseVisualStyleBackColor = false;
            this.btnback.Click += new System.EventHandler(this.btnback_Click);
            // 
            // btnadd
            // 
            this.btnadd.BackColor = System.Drawing.Color.Black;
            this.btnadd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnadd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnadd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadd.ForeColor = System.Drawing.Color.Red;
            this.btnadd.Location = new System.Drawing.Point(11, 320);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(157, 35);
            this.btnadd.TabIndex = 68;
            this.btnadd.Text = "Add";
            this.btnadd.UseVisualStyleBackColor = false;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click);
            // 
            // customertblBindingSource
            // 
            this.customertblBindingSource.DataMember = "Customertbl";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Lime;
            this.label4.Location = new System.Drawing.Point(10, 171);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 24);
            this.label4.TabIndex = 63;
            this.label4.Text = "Name";
            // 
            // IdTb
            // 
            this.IdTb.BackColor = System.Drawing.Color.Black;
            this.IdTb.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.IdTb.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IdTb.ForeColor = System.Drawing.Color.Red;
            this.IdTb.Location = new System.Drawing.Point(132, 94);
            this.IdTb.Margin = new System.Windows.Forms.Padding(4);
            this.IdTb.Name = "IdTb";
            this.IdTb.Size = new System.Drawing.Size(207, 29);
            this.IdTb.TabIndex = 61;
            this.IdTb.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.rid_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Yellow;
            this.label1.Location = new System.Drawing.Point(8, 134);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 24);
            this.label1.TabIndex = 60;
            this.label1.Text = "Carid";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(13, 97);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 24);
            this.label3.TabIndex = 59;
            this.label3.Text = "Id";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Black;
            this.panel2.Location = new System.Drawing.Point(0, 419);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(815, 26);
            this.panel2.TabIndex = 58;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Black;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(21, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(140, 85);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 38;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox2_Paint);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Algerian", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(302, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(205, 54);
            this.label2.TabIndex = 37;
            this.label2.Text = "Return";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(10, 206);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(114, 24);
            this.label5.TabIndex = 64;
            this.label5.Text = "ReturnDate";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(-4, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(819, 71);
            this.panel1.TabIndex = 57;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label10.ForeColor = System.Drawing.Color.Cyan;
            this.label10.Location = new System.Drawing.Point(786, 10);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(21, 20);
            this.label10.TabIndex = 39;
            this.label10.Text = "X";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Yellow;
            this.label6.Location = new System.Drawing.Point(13, 242);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 24);
            this.label6.TabIndex = 72;
            this.label6.Text = "Delay";
            // 
            // rdelay
            // 
            this.rdelay.BackColor = System.Drawing.Color.Black;
            this.rdelay.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rdelay.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdelay.ForeColor = System.Drawing.Color.Yellow;
            this.rdelay.Location = new System.Drawing.Point(132, 237);
            this.rdelay.Margin = new System.Windows.Forms.Padding(4);
            this.rdelay.Name = "rdelay";
            this.rdelay.Size = new System.Drawing.Size(207, 29);
            this.rdelay.TabIndex = 73;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Lime;
            this.label7.Location = new System.Drawing.Point(13, 279);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 24);
            this.label7.TabIndex = 74;
            this.label7.Text = "Fine";
            // 
            // rfine
            // 
            this.rfine.BackColor = System.Drawing.Color.Black;
            this.rfine.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rfine.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rfine.ForeColor = System.Drawing.Color.Lime;
            this.rfine.Location = new System.Drawing.Point(132, 277);
            this.rfine.Margin = new System.Windows.Forms.Padding(4);
            this.rfine.Name = "rfine";
            this.rfine.Size = new System.Drawing.Size(207, 29);
            this.rfine.TabIndex = 75;
            this.rfine.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.rfine_KeyPress);
            // 
            // rdate
            // 
            this.rdate.Location = new System.Drawing.Point(131, 204);
            this.rdate.Name = "rdate";
            this.rdate.Size = new System.Drawing.Size(208, 26);
            this.rdate.TabIndex = 76;
            // 
            // returntblBindingSource
            // 
            this.returntblBindingSource.DataMember = "Returntbl";
            // 
            // rentaltblBindingSource
            // 
            this.rentaltblBindingSource.DataMember = "Rentaltbl";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Black;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Yellow;
            this.label8.Location = new System.Drawing.Point(469, 237);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(144, 24);
            this.label8.TabIndex = 81;
            this.label8.Text = "Cars Returned";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Black;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(469, 73);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(131, 24);
            this.label9.TabIndex = 82;
            this.label9.Text = "Cars on Rent";
            // 
            // rentaltblBindingSource1
            // 
            this.rentaltblBindingSource1.DataMember = "Rentaltbl";
            // 
            // returntblBindingSource2
            // 
            this.returntblBindingSource2.DataMember = "Returntbl";
            // 
            // returntblBindingSource1
            // 
            this.returntblBindingSource1.DataMember = "Returntbl";
            // 
            // returncarid
            // 
            this.returncarid.BackColor = System.Drawing.Color.Black;
            this.returncarid.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.returncarid.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.returncarid.ForeColor = System.Drawing.Color.Yellow;
            this.returncarid.Location = new System.Drawing.Point(132, 129);
            this.returncarid.Margin = new System.Windows.Forms.Padding(4);
            this.returncarid.Name = "returncarid";
            this.returncarid.Size = new System.Drawing.Size(207, 29);
            this.returncarid.TabIndex = 85;
            // 
            // returnname
            // 
            this.returnname.BackColor = System.Drawing.Color.Black;
            this.returnname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.returnname.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.returnname.ForeColor = System.Drawing.Color.Lime;
            this.returnname.Location = new System.Drawing.Point(132, 166);
            this.returnname.Margin = new System.Windows.Forms.Padding(4);
            this.returnname.Name = "returnname";
            this.returnname.Size = new System.Drawing.Size(207, 29);
            this.returnname.TabIndex = 86;
            // 
            // btndelete
            // 
            this.btndelete.BackColor = System.Drawing.Color.Black;
            this.btndelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btndelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndelete.ForeColor = System.Drawing.Color.Yellow;
            this.btndelete.Location = new System.Drawing.Point(174, 320);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(164, 35);
            this.btndelete.TabIndex = 70;
            this.btndelete.Text = "Delete";
            this.btndelete.UseVisualStyleBackColor = false;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click_1);
            // 
            // rentaltblBindingSource2
            // 
            this.rentaltblBindingSource2.DataMember = "Rentaltbl";
            // 
            // returntblBindingSource3
            // 
            this.returntblBindingSource3.DataMember = "Returntbl";
            // 
            // rentaltblBindingSource3
            // 
            this.rentaltblBindingSource3.DataMember = "Rentaltbl";
            // 
            // returntblBindingSource4
            // 
            this.returntblBindingSource4.DataMember = "Returntbl";
            // 
            // rentaltblBindingSource4
            // 
            this.rentaltblBindingSource4.DataMember = "Rentaltbl";
            // 
            // returntblBindingSource5
            // 
            this.returntblBindingSource5.DataMember = "Returntbl";
            // 
            // returntblBindingSource6
            // 
            this.returntblBindingSource6.DataMember = "Returntbl";
            // 
            // rentDGV
            // 
            this.rentDGV.BackgroundColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Red;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.rentDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.rentDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.rentDGV.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rentDGV.Location = new System.Drawing.Point(373, 97);
            this.rentDGV.Name = "rentDGV";
            this.rentDGV.Size = new System.Drawing.Size(377, 133);
            this.rentDGV.TabIndex = 89;
            this.rentDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.rentDGV_CellContentClick);
            // 
            // returnDGV
            // 
            this.returnDGV.BackgroundColor = System.Drawing.Color.Black;
            this.returnDGV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.returnDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.returnDGV.Location = new System.Drawing.Point(373, 267);
            this.returnDGV.Name = "returnDGV";
            this.returnDGV.Size = new System.Drawing.Size(377, 133);
            this.returnDGV.TabIndex = 90;
            this.returnDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.returnDGV_CellContentClick_1);
            // 
            // Return
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(815, 444);
            this.Controls.Add(this.returnDGV);
            this.Controls.Add(this.rentDGV);
            this.Controls.Add(this.returnname);
            this.Controls.Add(this.returncarid);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.rdate);
            this.Controls.Add(this.rfine);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.rdelay);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btnback);
            this.Controls.Add(this.btndelete);
            this.Controls.Add(this.btnadd);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.IdTb);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "Return";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Return";
            this.Load += new System.EventHandler(this.Return_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Return_Paint);
            ((System.ComponentModel.ISupportInitialize)(this.customertblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.returntblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentaltblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentaltblBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.returntblBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.returntblBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentaltblBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.returntblBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentaltblBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.returntblBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentaltblBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.returntblBindingSource5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.returntblBindingSource6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentDGV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.returnDGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnback;
        private System.Windows.Forms.Button btnadd;
      //  private carrentalDataSet5TableAdapters.CustomertblTableAdapter customertblTableAdapter;
      //  private carrentalDataSet5 carrentalDataSet5;
        private System.Windows.Forms.BindingSource customertblBindingSource;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox IdTb;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox rdelay;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox rfine;
        private System.Windows.Forms.DateTimePicker rdate;
       // private carrentalDataSet12 carrentalDataSet12;
        private System.Windows.Forms.BindingSource returntblBindingSource;
       // private carrentalDataSet12TableAdapters.ReturntblTableAdapter returntblTableAdapter;
       // private carrentalDataSet13 carrentalDataSet13;
        private System.Windows.Forms.BindingSource rentaltblBindingSource;
      //  private carrentalDataSet13TableAdapters.RentaltblTableAdapter rentaltblTableAdapter;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
       // private carrentalDataSet14 carrentalDataSet14;
        private System.Windows.Forms.BindingSource rentaltblBindingSource1;
       // private carrentalDataSet14TableAdapters.RentaltblTableAdapter rentaltblTableAdapter1;
       // private carrentalDataSet15 carrentalDataSet15;
        private System.Windows.Forms.BindingSource returntblBindingSource1;
        //private carrentalDataSet15TableAdapters.ReturntblTableAdapter returntblTableAdapter1;
        private System.Windows.Forms.TextBox returncarid;
        private System.Windows.Forms.TextBox returnname;
        //private carrentalDataSet16 carrentalDataSet16;
        private System.Windows.Forms.BindingSource returntblBindingSource2;
        private System.Windows.Forms.Button btndelete;
       // private carrentalDataSet22 carrentalDataSet22;
        private System.Windows.Forms.BindingSource rentaltblBindingSource2;
        //private carrentalDataSet22TableAdapters.RentaltblTableAdapter rentaltblTableAdapter2;
       // private carrentalDataSet23 carrentalDataSet23;
        private System.Windows.Forms.BindingSource returntblBindingSource3;
        //private carrentalDataSet23TableAdapters.ReturntblTableAdapter returntblTableAdapter3;
       // private carrentalDataSet26 carrentalDataSet26;
        private System.Windows.Forms.BindingSource rentaltblBindingSource3;
        //private carrentalDataSet26TableAdapters.RentaltblTableAdapter rentaltblTableAdapter3;
       // private carrentalDataSet27 carrentalDataSet27;
        private System.Windows.Forms.BindingSource returntblBindingSource4;
       // private carrentalDataSet27TableAdapters.ReturntblTableAdapter returntblTableAdapter4;
       // private carrentalDataSet28 carrentalDataSet28;
        private System.Windows.Forms.BindingSource rentaltblBindingSource4;
       // private carrentalDataSet28TableAdapters.RentaltblTableAdapter rentaltblTableAdapter4;
       // private carrentalDataSet29 carrentalDataSet29;
        private System.Windows.Forms.BindingSource returntblBindingSource5;
       // private carrentalDataSet29TableAdapters.ReturntblTableAdapter returntblTableAdapter5;
       // private carrentalDataSet30 carrentalDataSet30;
        private System.Windows.Forms.BindingSource returntblBindingSource6;
        //private carrentalDataSet30TableAdapters.ReturntblTableAdapter returntblTableAdapter6;
        private System.Windows.Forms.DataGridView rentDGV;
        private System.Windows.Forms.DataGridView returnDGV;
        private System.Windows.Forms.Label label10;
    }
}