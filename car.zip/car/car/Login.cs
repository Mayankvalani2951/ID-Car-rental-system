﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace car
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|Datadirectory|carrental.mdf;Integrated Security=True");

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "select count(*) from  Usertbl where Uname='"+uname.Text+"' and Upass='"+upass.Text+"' ";
            SqlDataAdapter sda = new SqlDataAdapter(query,con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows[0][0].ToString()=="1")
            {
                Mainform mainform = new Mainform();
                mainform.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("wronng uname and upassword");
            }
            con.Close(); 
        }

        private void label4_Click(object sender, EventArgs e)
        {
            uname.Text = "";
            upass.Text = "";
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }
    }
}
