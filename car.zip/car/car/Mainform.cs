﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace car
{
    public partial class Mainform : Form
    {
        public Mainform()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

     

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Car car = new Car();
            car.Show();
            
        }

    

      /*  private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login l1=new Login();
            l1.Show();
            
        }*/

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Customer c1=new Customer(); 
            c1.Show();
           
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Rental r1= new Rental();
            r1.Show();
           
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Return r2 = new Return();
            r2.Show();
          
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Users u2= new Users();
            u2.Show();
          
        }

        

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
           Dashboard db = new Dashboard();
           db.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login login = new Login();
            login.Show();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            ControlPaint.DrawBorder(e.Graphics, this.panel1.ClientRectangle, Color.Red, ButtonBorderStyle.Solid);
        
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            Panel p = sender as Panel;
            ControlPaint.DrawBorder(e.Graphics, p.DisplayRectangle, Color.Yellow, ButtonBorderStyle.Inset);

        }

        private void Mainform_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Paint(object sender, PaintEventArgs e)
        {
            ControlPaint.DrawBorder(e.Graphics, this.pictureBox2.ClientRectangle, Color.Red, ButtonBorderStyle.Solid);
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
    }
}