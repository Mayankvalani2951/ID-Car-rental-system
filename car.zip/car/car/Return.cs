﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;

namespace car
{
    public partial class Return : Form
    {
        public Return()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|Datadirectory|carrental.mdf;Integrated Security=True");

        private void populate()
        {
            con.Open();
            string query = "select * from Rentaltbl ";
            SqlDataAdapter da = new SqlDataAdapter(query,con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            rentDGV.DataSource = ds.Tables[0];
            con.Close();

        }
        private void populateRet()
        {
            con.Open();
            string query = "select * from Returntbl ";
            SqlDataAdapter da = new SqlDataAdapter(query,con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            returnDGV.DataSource = ds.Tables[0];
            con.Close();


        }
          private void Deleteonreturn(string carid)
          {
           
              
              con.Open();
              string query = "delete from Rentaltbl where carReg= " + carid;
              SqlCommand cmd = new SqlCommand(query,con);
              cmd.ExecuteNonQuery();
             
              con.Close();
              populate();
            
          }
  





        private void Return_Load(object sender, EventArgs e)
        {
            string sql = "select * from Rentaltbl";
            SqlDataAdapter da = new SqlDataAdapter(sql, con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            rentDGV.DataSource = dt;

            string sql1 = "select * from Returntbl";
            SqlDataAdapter da1 = new SqlDataAdapter(sql1, con);
            DataTable dt1 = new DataTable();
            da.Fill(dt);
            returnDGV.DataSource = dt;


            populate();
            populateRet();
          

        }


         private void btnadd_Click(object sender, EventArgs e)
              {
            SqlConnection con1 = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|Datadirectory|carrental.mdf;Integrated Security=True");


            if (IdTb.Text == "" || returnname.Text == "" || rdate.Text == "" || rdelay.Text == ""|| rfine.Text == "")
                  {
                      MessageBox.Show("missing information");
                  }
                  else
                  {
                      try
                      {
                        string carid = returncarid.Text;
                        Deleteonreturn(carid);

                        con1.Open();
                          string query = "insert into Returntbl values(" + IdTb.Text + ",'" + returncarid.Text + "','" + returnname.Text + "','" + rdate.Text + "','" + rdelay.Text + "'," + rfine.Text + ")";
                          SqlCommand cmd = new SqlCommand(query, con1);
                          cmd.ExecuteNonQuery();
                          MessageBox.Show("success return");
                          populateRet();
                          IdTb.Text = returnname.Text =  rdate.Text = rdelay.Text =rfine.Text = string.Empty;
                    
                          con1.Close();

                        }
                      catch (Exception myex)
                      {
                          MessageBox.Show(myex.Message);
                      }
                  }

              }
    
        private void btnback_Click(object sender, EventArgs e)
        {
            this.Hide();
            Mainform m1 = new Mainform();
            m1.Show();
            
        }

       
        

        private void rid_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Only Number");
            }
        }

      

        private void rfine_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("Only Number");
            }
        }

    
      

        private void rentDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            returncarid.Text = rentDGV.Rows[e.RowIndex].Cells[1].Value.ToString();
            returnname.Text = rentDGV.Rows[e.RowIndex].Cells[2].Value.ToString();
            rdate.Text = rentDGV.Rows[e.RowIndex].Cells[4].Value.ToString();
            DateTime d1 = rdate.Value.Date;
            DateTime d2 = DateTime.Now;
            TimeSpan t = d2 - d1;
            int NrofDays = Convert.ToInt32(t.TotalDays);
            if (NrofDays <= 0)
            {
                rdelay.Text = "No Delay";
                rfine.Text = "0";

            }
            else
            {
                rdelay.Text = "" + NrofDays;
                rfine.Text = "" + (NrofDays * 250);

            }
        }
    }
}
